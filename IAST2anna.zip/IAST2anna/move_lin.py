from move2dir import move
move('res_intLang')
